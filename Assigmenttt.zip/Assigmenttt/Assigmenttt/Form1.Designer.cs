﻿namespace Assigmenttt
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            groupBox1 = new GroupBox();
            txtAge = new TextBox();
            txtID = new TextBox();
            txtName = new TextBox();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            rbFemale = new RadioButton();
            rbMale = new RadioButton();
            clbCourses = new ListBox();
            btnSubmit = new Button();
            lblOutput = new Label();
            btnClear = new Button();
            extra = new CheckBox();
            btnExit = new Button();
            pictureBox1 = new PictureBox();
            groupBox2 = new GroupBox();
            groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            groupBox2.SuspendLayout();
            SuspendLayout();
            // 
            // groupBox1
            // 
            groupBox1.BackColor = Color.WhiteSmoke;
            groupBox1.Controls.Add(txtAge);
            groupBox1.Controls.Add(txtID);
            groupBox1.Controls.Add(txtName);
            groupBox1.Controls.Add(label3);
            groupBox1.Controls.Add(label2);
            groupBox1.Controls.Add(label1);
            groupBox1.Controls.Add(rbFemale);
            groupBox1.Controls.Add(rbMale);
            groupBox1.Location = new Point(6, 32);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(351, 261);
            groupBox1.TabIndex = 0;
            groupBox1.TabStop = false;
            groupBox1.Text = "Student information";
            // 
            // txtAge
            // 
            txtAge.Location = new Point(162, 138);
            txtAge.Name = "txtAge";
            txtAge.Size = new Size(185, 31);
            txtAge.TabIndex = 2;
            // 
            // txtID
            // 
            txtID.Location = new Point(162, 85);
            txtID.Name = "txtID";
            txtID.Size = new Size(185, 31);
            txtID.TabIndex = 2;
            // 
            // txtName
            // 
            txtName.Location = new Point(162, 39);
            txtName.Name = "txtName";
            txtName.Size = new Size(185, 31);
            txtName.TabIndex = 2;
            // 
            // label3
            // 
            label3.BackColor = Color.White;
            label3.BorderStyle = BorderStyle.Fixed3D;
            label3.ImageAlign = ContentAlignment.TopLeft;
            label3.Location = new Point(6, 138);
            label3.Name = "label3";
            label3.Size = new Size(135, 31);
            label3.TabIndex = 1;
            label3.Text = "&Age:";
            label3.TextAlign = ContentAlignment.TopRight;
            // 
            // label2
            // 
            label2.BackColor = Color.White;
            label2.BorderStyle = BorderStyle.Fixed3D;
            label2.Location = new Point(6, 85);
            label2.Name = "label2";
            label2.Size = new Size(135, 31);
            label2.TabIndex = 1;
            label2.Text = "&Student ID:";
            label2.TextAlign = ContentAlignment.TopRight;
            // 
            // label1
            // 
            label1.BackColor = Color.White;
            label1.BorderStyle = BorderStyle.Fixed3D;
            label1.Location = new Point(6, 42);
            label1.Name = "label1";
            label1.Size = new Size(135, 28);
            label1.TabIndex = 1;
            label1.Text = "&Student Name:";
            label1.TextAlign = ContentAlignment.TopRight;
            // 
            // rbFemale
            // 
            rbFemale.AutoSize = true;
            rbFemale.BackColor = Color.FromArgb(255, 255, 192);
            rbFemale.Location = new Point(206, 215);
            rbFemale.Name = "rbFemale";
            rbFemale.Size = new Size(93, 29);
            rbFemale.TabIndex = 3;
            rbFemale.TabStop = true;
            rbFemale.Text = "Female";
            rbFemale.UseVisualStyleBackColor = false;
            // 
            // rbMale
            // 
            rbMale.AutoSize = true;
            rbMale.BackColor = Color.FromArgb(255, 255, 192);
            rbMale.Location = new Point(23, 215);
            rbMale.Name = "rbMale";
            rbMale.Size = new Size(75, 29);
            rbMale.TabIndex = 3;
            rbMale.TabStop = true;
            rbMale.Text = "Male";
            rbMale.UseVisualStyleBackColor = false;
            // 
            // clbCourses
            // 
            clbCourses.FormattingEnabled = true;
            clbCourses.ItemHeight = 25;
            clbCourses.Items.AddRange(new object[] { "Java", "C#", "HTML&CSS3", "React" });
            clbCourses.Location = new Point(6, 303);
            clbCourses.Name = "clbCourses";
            clbCourses.Size = new Size(180, 129);
            clbCourses.TabIndex = 4;
            // 
            // btnSubmit
            // 
            btnSubmit.BackColor = Color.DeepSkyBlue;
            btnSubmit.Location = new Point(6, 438);
            btnSubmit.Name = "btnSubmit";
            btnSubmit.Size = new Size(112, 34);
            btnSubmit.TabIndex = 6;
            btnSubmit.Text = "&Submit";
            btnSubmit.UseVisualStyleBackColor = false;
            btnSubmit.Click += btnSubmit_Click;
            // 
            // lblOutput
            // 
            lblOutput.BackColor = Color.DodgerBlue;
            lblOutput.Location = new Point(6, 483);
            lblOutput.Name = "lblOutput";
            lblOutput.Size = new Size(351, 176);
            lblOutput.TabIndex = 1;
            // 
            // btnClear
            // 
            btnClear.BackColor = Color.DeepSkyBlue;
            btnClear.Location = new Point(124, 438);
            btnClear.Name = "btnClear";
            btnClear.Size = new Size(112, 34);
            btnClear.TabIndex = 6;
            btnClear.Text = "&Clear";
            btnClear.UseVisualStyleBackColor = false;
            btnClear.Click += btnClear_Click;
            // 
            // extra
            // 
            extra.AutoSize = true;
            extra.BackColor = Color.FromArgb(255, 255, 192);
            extra.Location = new Point(203, 303);
            extra.Name = "extra";
            extra.Size = new Size(154, 29);
            extra.TabIndex = 7;
            extra.Text = "extra-curricular";
            extra.UseVisualStyleBackColor = false;
            // 
            // btnExit
            // 
            btnExit.BackColor = Color.DeepSkyBlue;
            btnExit.Location = new Point(245, 438);
            btnExit.Name = "btnExit";
            btnExit.Size = new Size(112, 34);
            btnExit.TabIndex = 6;
            btnExit.Text = "E&xit";
            btnExit.UseVisualStyleBackColor = false;
            btnExit.Click += btnExit_Click;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(255, 4);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(228, 97);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 8;
            pictureBox1.TabStop = false;
            // 
            // groupBox2
            // 
            groupBox2.BackColor = Color.Cyan;
            groupBox2.Controls.Add(lblOutput);
            groupBox2.Controls.Add(btnSubmit);
            groupBox2.Controls.Add(groupBox1);
            groupBox2.Controls.Add(extra);
            groupBox2.Controls.Add(btnClear);
            groupBox2.Controls.Add(clbCourses);
            groupBox2.Controls.Add(btnExit);
            groupBox2.Location = new Point(200, 102);
            groupBox2.Name = "groupBox2";
            groupBox2.Size = new Size(363, 669);
            groupBox2.TabIndex = 9;
            groupBox2.TabStop = false;
            groupBox2.Text = "Student Management";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(0, 192, 192);
            ClientSize = new Size(1185, 783);
            Controls.Add(groupBox2);
            Controls.Add(pictureBox1);
            Name = "Form1";
            Text = "Form1";
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            groupBox2.ResumeLayout(false);
            groupBox2.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private GroupBox groupBox1;
        private TextBox txtAge;
        private TextBox txtID;
        private TextBox txtName;
        private Label label3;
        private Label label2;
        private Label label1;
        private RadioButton rbFemale;
        private RadioButton rbMale;
        private ListBox clbCourses;
        private Button btnSubmit;
        private Label lblOutput;
        private Button btnClear;
        private CheckBox extra;
        private Button btnExit;
        private PictureBox pictureBox1;
        private GroupBox groupBox2;
    }
}
